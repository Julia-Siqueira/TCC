<?php  
$link = mysqli_connect("127.0.0.1", "root", "", NULL, "3307", NULL)
or die(mysqli_error());

mysqli_select_db($link, "escalas") or die(mysqli_error($link));

?>