<?php
    include("conexao.php");

    $pesquisar=$_POST['pesquisar'];
    $resultado="SELECT * FROM cadastro WHERE id LIKE '%$pesquisar%' LIMIT 5";
    $resultado_membro=mysqli_query($conexao, $resultado);

    while($rows_membro=mysqli_fetch_array($resultado_membro)){
        echo "<p style='font-size:1.25em; font-family: Arial;'>Nome: ".$rows_membro['nome']."<br>";
        echo "Sobrenome: ".$rows_membro['sobrenome']."<br>";
        echo "Sexo: ".$rows_membro['sexo']."<br>";
        echo "Data de nascimento: ".$rows_membro['nascimento']."<br>";
        echo "Endereço: ".$rows_membro['endereco']."<br>";
        echo "Telefone: ".$rows_membro['telefone']."<br>";
        echo "Tipo sanguíneo: ".$rows_membro['tipo']."<br>";
        echo "E-mail: ".$rows_membro['email']."<br>";
        echo "Geração: ".$rows_membro['geracao']."<br>";
        echo "Líder: ".$rows_membro['lider']."<br>";
    }

?>