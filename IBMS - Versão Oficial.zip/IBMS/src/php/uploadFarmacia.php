<?php

$arquivo = $_FILES["arquivo"]["name"];
$tipo = $_FILES["arquivo"]["type"];

$dir = "../../fotos/";
$imgTypes = array("image/jpeg", "image/jpg", "image/png", "image/bmp", "image/gif");

if(is_file($_FILES["arquivo"]["tmp_name"])){
    if(file_exists($dir . $arquivo)){
       $cont = 1;
       while(file_exists("../../fotos/[$cont]$arquivo")){
        $cont++;
       }
       $arquivo = "[$cont] $arquivo";
    }
    if(in_array($tipo, $imgTypes)){

        include_once 'conexaoFarmacia.php';
        $query = "INSERT INTO farmacia(foto)VALUES('$arquivo')";

        if(mysqli_query($link, $query)){
            if(move_uploaded_file($_FILES["arquivo"]["tmp_name"], $dir.$arquivo)){
                echo "<script>alert('Arquivo recebido com sucesso'); location='../controle/controlebd.html'</script>";
            }
        }
    }else{
        echo "<script>alert('Tipo de arquivo inválido'); location='../controle/controlebd.html'</script>";
    }
}


?>