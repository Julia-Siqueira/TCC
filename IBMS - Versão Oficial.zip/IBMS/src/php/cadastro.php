<?php
  include("conexao.php");

  $nome=$_POST['nome'];
  $sobrenome=$_POST['sobrenome'];
  $sexo=$_POST['sexo'];
  $nascimento=$_POST['nascimento'];
  $endereco=$_POST['endereco'];
  $telefone=$_POST['telefone'];
  $email=$_POST['email'];
  $tipo=$_POST['tipo'];
  $geracao=$_POST['geracao'];
  $lider=$_POST['lider'];
  


  $sql="INSERT INTO cadastro(nome, sobrenome, sexo, nascimento, endereco, telefone, tipo, email, geracao, lider) 
        VALUES ('$nome', '$sobrenome', '$sexo', '$nascimento', '$endereco', '$telefone', '$tipo', '$email', '$geracao', '$lider')";

        if(mysqli_query($conexao, $sql)){
            echo "Usuário cadastrado com sucesso";
        }
        else{
            echo "Erro".mysqli_connect_error($conexao);
        }
        mysqli_close($conexao);
?>