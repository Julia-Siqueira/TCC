<!DOCTYPE html>
<html lang="pt-br">

  <head>
    <title>Título da página</title>
    <meta charset="utf-8">
  </head>

  <body>
    <?php
    include("conexao.php");

    
    $id=$_POST['id'];
    $sql="DELETE FROM cadastro WHERE id='$id' ";

    if(mysqli_query($conexao, $sql)){
        echo "Cadastro excluído";
    }
    else{
        echo "A operação não foi realizada. Por favor, tente novamente".mysqli_error($conexao);
    }

    mysqli_close($conexao)

    ?>

  </body>
</html>