<?php
include("conexao.php");


$id=$_POST['id'];
$nome=$_POST['nome'];
$sobrenome=$_POST['sobrenome'];
$sexo=$_POST['sexo'];
$nascimento=$_POST['nascimento'];
$endereco=$_POST['endereco'];
$telefone=$_POST['telefone'];
$tipo=$_POST['tipo'];
$email=$_POST['email'];
$geracao=$_POST['geracao'];
$lider=$_POST['lider'];


$sql = "UPDATE cadastro SET 

nome='$nome',
sobrenome='$sobrenome',
sexo='$sexo',
nascimento='$nascimento',
endereco='$endereco',
telefone='$telefone',
tipo='$tipo',
email='$email',
geracao='$geracao',
lider='$lider'
WHERE id='$id'";

$resultado=mysqli_query($conexao, $sql);
if ($resultado){
    echo "Membro atualizado com sucesso";
}
else{
    echo "Não foi possível atualizar. Por favor, tente novamente.";
}
mysqli_close($conexao);
?>