<!DOCTYPE html>
<html lang="pt-br">


  <head>
    <title>Escala do Ministério Profético</title>
    <meta charset="utf-8">
    <link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather Sans' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../escalascss/profetico.css">
  </head>


  <body>
   
    <h1>Escala do mês do Ministério Profético</h1>

    
    <?php
      include_once '../php/conexaoEscalas.php';
      $query = "SELECT * FROM escalas WHERE id LIKE 8";
      $result = mysqli_query($link, $query);
      while($array = mysqli_fetch_assoc($result)){
   ?>

   <div id="album">
    <img class="imagem" src="../../fotos/<?=$array['foto']?>" alt="Foto Álbum" width="1000px" height="250px">
   </div>

   <?php } ?>

   <br>
      </br>

   <?php
      include_once '../php/conexaoEscalas.php';
      $query = "SELECT * FROM escalas WHERE id LIKE 9";
      $result = mysqli_query($link, $query);
      while($array = mysqli_fetch_assoc($result)){
   ?>

   <div id="album">
    <img class="imagem" src="../../fotos/<?=$array['foto']?>" alt="Foto Álbum" width="1000px" height="250px">
   </div>

   <?php } ?>



  
  </body>
</html>