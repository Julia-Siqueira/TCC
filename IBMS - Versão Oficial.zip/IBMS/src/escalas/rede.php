<!DOCTYPE html>
<html lang="pt-br">


  <head>
    <title>Escala da Rede Criar</title>
    <meta charset="utf-8">
    <link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather Sans' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Annie Use Your Telescope' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../escalascss/rede.css">
  </head>


  <body>
   
    <h1>Escala do mês da Rede Criar</h1>

    
    <?php
      include_once '../php/conexaoEscalas.php';
      $query = "SELECT * FROM escalas WHERE id LIKE 3";
      $result = mysqli_query($link, $query);
      while($array = mysqli_fetch_assoc($result)){
   ?>

   <div id="album">
    <img class="imagem" src="../../fotos/<?=$array['foto']?>" alt="Foto Álbum" width="1000px" height="250px">
   </div>

   <?php } ?>

   <br>
      </br>

   <?php
      include_once '../php/conexaoEscalas.php';
      $query = "SELECT * FROM escalas WHERE id LIKE 4";
      $result = mysqli_query($link, $query);
      while($array = mysqli_fetch_assoc($result)){
   ?>

   <div id="album">
    <img class="imagem" src="../../fotos/<?=$array['foto']?>" alt="Foto Álbum" width="1000px" height="250px">
   </div>

   <?php } ?>

   <br>
      </br>


  
  </body>
</html>