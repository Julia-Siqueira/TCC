<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Farmácia Solidária</title>

    <link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather Sans' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Annie Use Your Telescope' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../ramoscss/farmacia_solidaria.css">

    <link rel="icon"
      type="image/png"
      href="../../assets/img/farmacia_icon.png"/>

    <meta charset="utf-8">
  </head>
  <body>
    <br>
    <h1>Farmácia Solidária</h1>
    <div class="div">
        <p class="p">
          Abençoando famílias através de doação de medicamentos mediante apresentação da receita médica.
          <br>
          <n>Segunda:</n> Das 18h às 19h e <n>Terça:</n> Das 16h30 às 17h30.
    </p> 
    </div>
    

    <br>
    <br>

    <?php
      include_once '../php/conexaoFarmacia.php';
      $query = "SELECT * FROM farmacia";
      $result = mysqli_query($link, $query);
      while($array = mysqli_fetch_assoc($result)){
   ?>

   <div id="album">
    <img class="imagem" src="../../fotos/<?=$array['foto']?>" alt="Foto Álbum" >
   </div>

   <?php } ?>

  </body>
</html>