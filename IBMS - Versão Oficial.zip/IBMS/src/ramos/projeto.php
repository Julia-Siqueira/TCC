<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Projeto Mão Amiga </title>

    <link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather Sans' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../ramoscss/projeto.css">
    <link href='https://fonts.googleapis.com/css?family=Pangolin' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=IM Fell DW Pica' rel='stylesheet'>

    <link rel="icon"
      type="image/png"
      href="../../assets/img/projeto_icon.png"/>

    <meta charset="utf-8">
  </head>
  <body>
    <h1>Projeto Mão Amiga</h1>
    <br>
    <div class="div">
      <p class="p">
        Uma Igreja que se reune para servir aqueles que não estão em seu estado de justiça, 
        no Hospital Mario Covas.
  </p>
  </div>
<br>

<div id="div2">
  <p id="p2">
    Todas as sextas, às 19:30
  </p>
</div>

<br>
</br>

<?php
      include_once '../php/conexaoProjeto.php';
      $query = "SELECT * FROM projeto";
      $result = mysqli_query($link, $query);
      while($array = mysqli_fetch_assoc($result)){
   ?>

   <div id="album">
    <img class="imagem" src="../../fotos/<?=$array['foto']?>" alt="Foto Álbum" >
   </div>

   <?php } ?>

  </body>
</html>