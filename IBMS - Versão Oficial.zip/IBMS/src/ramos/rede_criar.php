<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Rede Criar</title>
    <link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather Sans' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Annie Use Your Telescope' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Itim' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Delius' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../ramoscss/main_rede_criar.css">
    
    <link rel="icon"
      type="image/png"
      href="../../assets/img/criar_icon.png"/>

    <meta charset="utf-8">
  </head>
  <body>
    <h1>Rede Criar</h1>
    <h2>Meu filho acessando O Reino</h2>

    <div class="div">
        <p class="p">
          A Rede Criar tem como objetivo levar a Palavra até os pequeninos com amor e fidelidade.
          <br>
          <br>
          Horários:<br>
          - Sábados: células das 9h às 10h<br>
          - Domingos: durante os cultos (8h e 18h)
    </p> 
    </div>

   <h1>Álbum de fotos</h1>

   <?php
      include_once '../php/conexaoAlbum.php';
      $query = "SELECT * FROM upload";
      $result = mysqli_query($link, $query);
      while($array = mysqli_fetch_assoc($result)){
   ?>

   <div id="album">
    <img class="imagem" src="../../fotos/<?=$array['foto']?>" alt="Foto Álbum" >
   </div>

   <?php } ?>

  </body>
</html>